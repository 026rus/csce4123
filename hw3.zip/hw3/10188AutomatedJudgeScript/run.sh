#cat text.txt;
#echo; 
#echo "xxxxxxxxxxxxxxxxxx"; 
#echo; 
cat text.txt | ./run;
